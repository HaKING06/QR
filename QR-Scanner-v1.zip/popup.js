document.addEventListener('DOMContentLoaded', () => {
    // 1. ODAKLANMA SORUNUNU ÇÖZ (Ctrl+V için şart)
    window.focus(); 
    
    // 2. Eventler
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');

    // Tıklayınca dosya seç
    dropZone.onclick = () => fileInput.click();
    fileInput.onchange = (e) => { if(e.target.files.length) processFile(e.target.files[0]); };

    // Sürükle Bırak
    dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.style.borderColor = '#007aff'; });
    dropZone.addEventListener('dragleave', (e) => { e.preventDefault(); dropZone.style.borderColor = ''; });
    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        if(e.dataTransfer.files.length) processFile(e.dataTransfer.files[0]);
    });

    // Yapıştırma (Paste)
    document.addEventListener('paste', (e) => {
        const items = e.clipboardData.items;
        for (const item of items) {
            if (item.type.indexOf('image') !== -1) {
                processFile(item.getAsFile());
                return; // İlk resmi al ve çık
            }
        }
    });

    // Butonlar
    document.getElementById('btn-reset').onclick = resetView;
    
    // Kopyala
    const btnCopy = document.getElementById('btn-copy');
    btnCopy.onclick = () => {
        document.getElementById('qr-result').select();
        document.execCommand('copy');
        btnCopy.innerText = "Kopyalandı";
        setTimeout(() => btnCopy.innerText = "Kopyala", 1000);
    };
});

function processFile(file) {
    if (!file.type.startsWith('image/')) return showToast("Sadece resim dosyası!");
    
    const reader = new FileReader();
    reader.onload = (e) => {
        const img = new Image();
        img.onload = () => scanQR(img);
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function scanQR(img) {
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0);

    if (typeof jsQR === 'undefined') return showToast("Hata: jsQR bulunamadı.");

    try {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        if (code) showResult(code.data);
        else showToast("QR Kod bulunamadı.");
    } catch (err) {
        showToast("Okuma hatası.");
    }
}

function analyzeLink(text) {
    // Güvenlik Mantığı (Sadeleştirilmiş)
    if (!text.match(/^https?:\/\//i)) return { type: 'sec-text', icon: '📝', msg: 'Metin İçeriği' };
    if (text.startsWith('http://')) return { type: 'sec-danger', icon: '🔓', msg: 'Güvenli Değil (HTTP)' };
    
    // Şüpheli kontrolü
    const suspicious = ['bit.ly', 'goo.gl', '@', '192.168'];
    if (suspicious.some(s => text.includes(s))) return { type: 'sec-warn', icon: '⚠️', msg: 'Dikkat: Şüpheli Link' };

    return { type: 'sec-safe', icon: '🔒', msg: 'Güvenli Bağlantı (HTTPS)' };
}

function showResult(text) {
    document.getElementById('scan-view').classList.add('hidden');
    document.getElementById('result-view').classList.remove('hidden');
    
    const textArea = document.getElementById('qr-result');
    textArea.value = text;

    const sec = analyzeLink(text);
    const secBox = document.getElementById('sec-box');
    const btnOpen = document.getElementById('btn-open');

    // Güvenlik UI
    secBox.className = `security-status ${sec.type}`;
    document.getElementById('sec-icon').innerText = sec.icon;
    document.getElementById('sec-text').innerText = sec.msg;

    // Link Butonu
    if (sec.type === 'sec-text') {
        btnOpen.classList.add('hidden');
    } else {
        btnOpen.classList.remove('hidden');
        btnOpen.onclick = () => window.open(text, '_blank');
        
        // Eğer tehlikeliyse butonu kırmızı yap
        btnOpen.style.background = sec.type === 'sec-danger' ? '#ff3b30' : '';
    }
}

function resetView() {
    document.getElementById('result-view').classList.add('hidden');
    document.getElementById('scan-view').classList.remove('hidden');
    document.getElementById('file-input').value = "";
    document.getElementById('qr-result').value = "";
}

function showToast(msg) {
    const t = document.getElementById('toast');
    t.innerText = msg;
    t.classList.remove('hidden');
    setTimeout(() => t.classList.add('hidden'), 2000);
}