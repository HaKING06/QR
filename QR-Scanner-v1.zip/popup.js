document.addEventListener('DOMContentLoaded', () => {
    window.focus(); 

    // TAB GEÇİŞLERİ
    const tabs = document.querySelectorAll('.nav-btn');
    const panels = document.querySelectorAll('.view-panel');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const target = tab.getAttribute('data-target');
            panels.forEach(p => {
                p.classList.add('hidden');
                if(p.id === target) p.classList.remove('hidden');
            });
        });
    });

    // SCANNER
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    
    dropZone.onclick = () => fileInput.click();
    fileInput.onchange = (e) => { if(e.target.files.length) processFile(e.target.files[0]); };

    document.addEventListener('paste', (e) => {
        if (!document.getElementById('scan-view').classList.contains('hidden')) {
            const items = e.clipboardData.items;
            for (const item of items) {
                if (item.type.indexOf('image') !== -1) {
                    processFile(item.getAsFile());
                    return;
                }
            }
        }
    });

    document.getElementById('btn-reset').onclick = resetScan;
    
    document.getElementById('btn-copy-scan').onclick = () => {
        const txt = document.getElementById('qr-result');
        txt.select();
        document.execCommand('copy');
        showToast("Kopyalandı");
    };

    // GENERATOR
    const btnGenerate = document.getElementById('btn-generate');
    const qrInput = document.getElementById('qr-input');
    const qrDisplay = document.getElementById('qrcode-display');
    const genActions = document.getElementById('generator-actions');

    btnGenerate.onclick = () => {
        const text = qrInput.value.trim();
        if (!text) return showToast("Metin giriniz");
        
        qrDisplay.innerHTML = ""; 
        try {
            new QRCode(qrDisplay, {
                text: text,
                width: 200,
                height: 200,
                colorDark : "#000000",
                colorLight : "#ffffff",
                correctLevel : QRCode.CorrectLevel.M
            });
            genActions.classList.remove('hidden');
            btnGenerate.innerText = "Yeniden Oluştur";
        } catch (e) { showToast("Hata oluştu"); }
    };

    document.getElementById('btn-download-qr').onclick = () => {
        const img = qrDisplay.querySelector('img');
        if (img) {
            const link = document.createElement('a');
            link.href = img.src;
            link.download = 'qr-code.png';
            link.click();
        }
    };

    document.getElementById('btn-copy-qr').onclick = async () => {
        const img = qrDisplay.querySelector('img');
        if (img) {
            try {
                const response = await fetch(img.src);
                const blob = await response.blob();
                await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
                showToast("Panoya Kopyalandı");
            } catch (err) { showToast("Kopyalama Hatası"); }
        }
    };
});

function processFile(file) {
    if (!file.type.startsWith('image/')) return showToast("Sadece resim dosyası!");
    const reader = new FileReader();
    reader.onload = (e) => {
        const img = new Image();
        img.onload = () => scanQR(img);
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

// --- AKILLI TARAMA (GÜÇLENDİRİLMİŞ) ---
function scanQR(img) {
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    // 1. Orijinal
    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0);
    
    let code = attemptScan(canvas, ctx);

    // 2. Siyah-Beyaz (Yoğun QR için)
    if (!code) {
        binarizeImage(canvas, ctx);
        code = attemptScan(canvas, ctx);
    }

    // 3. 2x Zoom
    if (!code) {
        canvas.width = img.width * 2;
        canvas.height = img.height * 2;
        ctx.imageSmoothingEnabled = false; 
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        code = attemptScan(canvas, ctx);
    }

    if (code) {
        showResult(code.data);
    } else {
        showToast("QR Kod Bulunamadı");
    }
}

function attemptScan(canvas, ctx) {
    try {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        return jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: "attemptBoth",
        });
    } catch { return null; }
}

function binarizeImage(canvas, ctx) {
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    for (let i = 0; i < data.length; i += 4) {
        const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
        const color = avg > 120 ? 255 : 0; 
        data[i] = color; data[i + 1] = color; data[i + 2] = color;
    }
    ctx.putImageData(imageData, 0, 0);
}

// --- DETAYLI ANALİZ MOTORU ---
function analyzeContent(text) {
    // 1. SİSTEM / TARAYICI LİNKLERİ
    if (text.startsWith('chrome://') || text.startsWith('edge://') || text.startsWith('about:') || text.startsWith('file://')) {
        return {
            type: 'system',
            label: 'Sistem Adresi',
            class: 'status-system',
            icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />',
            canOpen: false 
        };
    }

    // 2. GÜVENLİ WEB (HTTPS)
    if (text.startsWith('https://')) {
        return {
            type: 'safe',
            label: 'Güvenli Bağlantı (HTTPS)',
            class: 'status-safe',
            icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />',
            canOpen: true
        };
    }

    // 3. GÜVENSİZ WEB (HTTP)
    if (text.startsWith('http://')) {
        return {
            type: 'warn',
            label: 'Bağlantı Şifreli Değil (HTTP)',
            class: 'status-warn',
            icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />',
            canOpen: true
        };
    }

    // 4. İLETİŞİM (Mail/Tel/SMS)
    if (text.startsWith('mailto:') || text.startsWith('tel:') || text.startsWith('sms:')) {
        return {
            type: 'info',
            label: 'İletişim Adresi',
            class: 'status-info',
            icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />',
            canOpen: true
        };
    }

    // 5. WIFI
    if (text.startsWith('WIFI:')) {
        return {
            type: 'wifi',
            label: 'Wi-Fi Ağı',
            class: 'status-wifi',
            icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0" />',
            canOpen: false // Wifi metin olarak kopyalanır
        };
    }

    // 6. VARSAYILAN: METİN
    return {
        type: 'text',
        label: 'Metin İçeriği',
        class: 'status-text',
        icon: '<path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />',
        canOpen: false
    };
}

function showResult(text) {
    document.getElementById('drop-zone').classList.add('hidden');
    document.getElementById('result-view').classList.remove('hidden');
    document.getElementById('qr-result').value = text;
    
    const secBox = document.getElementById('sec-box');
    const secText = document.getElementById('sec-text');
    const btnOpen = document.getElementById('btn-open');
    
    // Analiz Motorunu Çalıştır
    const status = analyzeContent(text);

    // Sonuçları Uygula
    secBox.className = `status-badge ${status.class}`;
    secBox.innerHTML = `${'<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">' + status.icon + '</svg>'} <span>${status.label}</span>`;

    // Buton Durumu
    if (status.canOpen) {
        btnOpen.classList.remove('hidden');
        btnOpen.onclick = () => window.open(text, '_blank');
    } else {
        btnOpen.classList.add('hidden'); // Sistem veya Metin ise aç butonu gizlenir
    }
}

function resetScan() {
    document.getElementById('result-view').classList.add('hidden');
    document.getElementById('drop-zone').classList.remove('hidden');
    document.getElementById('file-input').value = "";
    document.getElementById('qr-result').value = "";
}

function showToast(msg) {
    const t = document.getElementById('toast');
    t.innerText = msg;
    t.classList.remove('hidden');
    setTimeout(() => t.classList.add('hidden'), 2000);
}